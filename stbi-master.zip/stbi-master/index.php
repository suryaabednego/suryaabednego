
<html >
<head>
<title>SURYA ABEDNEGO</title>
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h1 align="center" type="text/css">STBI-UTS UNISBANK-SEMARANG</h1>
<hr>
</body>
<div align="center">
<div class="menu-wrap">
  <div class="menu">
    <ul>
      <li><a href="Upload.php">Upload File PDF</a></li>
      <li><a href="hitungbobot.php">Hitung Bobot </a></li>
      <li><a href="hitungvektor.php">HitungVektor </a></li>
      <li><a href="awalquery.php">Tampilkan Cache </a></li>
      <li><a href="Stemming.php">Pencarian Kata Dasar </a></li>
	  <li><a href="query.php">Pencarian Query </a></li>
	  <li><a href="download.php">Download </a></li>
    </ul>
  </div>
</div>
</html>